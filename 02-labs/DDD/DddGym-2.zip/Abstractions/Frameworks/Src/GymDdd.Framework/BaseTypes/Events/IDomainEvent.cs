﻿using MediatR;

namespace GymDdd.Framework.BaseTypes.Events;

public interface IDomainEvent : INotification
{
}