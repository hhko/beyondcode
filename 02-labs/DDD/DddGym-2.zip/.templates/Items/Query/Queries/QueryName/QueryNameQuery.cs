﻿using SolutionName.Framework.BaseTypes.Application.Cqrs;

namespace HostName.Application.Usecases.EntityNames.Queries.QueryName;

public sealed record QueryNameQuery()
    : IQuery<QueryNameResponse>;