﻿namespace GymDdd.Tests.Architecture.Abstractions.Constants;

public static partial class Constants
{
    public static class UnitTest
    {
        public const string Architecture = nameof(Architecture);
    }
}