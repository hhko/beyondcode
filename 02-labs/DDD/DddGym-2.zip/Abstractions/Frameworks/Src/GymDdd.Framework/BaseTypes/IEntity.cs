﻿namespace GymDdd.Framework.BaseTypes;

public interface IEntity
{
    const string CreateMethodName = "Create";
}
