﻿namespace GymManagement.Tests.Unit.Abstractions.Constants;

public static partial class AssemblyConstants
{
    public static class CollectionName
    {
        //public const string ServiceProviderCollectionDefinition = nameof(ServiceProviderCollectionDefinition);

        public const string WebAppFactoryCollectionDefinition = nameof(WebAppFactoryCollectionDefinition);
    }
}