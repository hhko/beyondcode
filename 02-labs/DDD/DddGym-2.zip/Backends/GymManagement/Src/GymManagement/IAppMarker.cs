﻿namespace GymManagement;

public interface IAppMarker;
