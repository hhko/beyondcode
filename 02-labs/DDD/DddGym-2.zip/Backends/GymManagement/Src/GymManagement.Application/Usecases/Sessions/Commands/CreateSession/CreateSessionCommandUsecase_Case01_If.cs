﻿//using GymDdd.Framework.BaseTypes.Cqrs;
//using GymManagement.Domain.Abstractions.SharedTypes.ValueObjects;
//using GymManagement.Domain.AggregateRoots.Rooms;
//using GymManagement.Domain.AggregateRoots.Sessions;
//using GymManagement.Domain.AggregateRoots.Trainers;
//using LanguageExt;
//using LanguageExt.Common;

//namespace GymManagement.Application.Usecases.Sessions.Commands.CreateSession;



