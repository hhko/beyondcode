﻿namespace GymManagement.Application.Usecases.Authentication.Errors;

//// TODO: LanguageExt
//public static partial class ApplicationErrors
//{
//    public static class LoginQueryErrors
//    {
//        public static readonly Error InvalidCredentials = Error.Validation(
//            code: $"{nameof(ApplicationErrors)}.{nameof(LoginQuery)}.{nameof(InvalidCredentials)}",
//            description: "Invalid credentials");
//    }
//}
