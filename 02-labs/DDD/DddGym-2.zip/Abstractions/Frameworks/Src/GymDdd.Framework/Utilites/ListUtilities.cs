﻿namespace GymDdd.Framework.Utilites;

public static class ListUtilities
{
    public static List<TValue> EmptyList<TValue>()
    {
        return [];
    }
}
