﻿namespace GymDdd.Framework.Tests.Unit.Abstractions.Constants;

public static partial class Constants
{
    public static class NamingConvention
    {
    }
}