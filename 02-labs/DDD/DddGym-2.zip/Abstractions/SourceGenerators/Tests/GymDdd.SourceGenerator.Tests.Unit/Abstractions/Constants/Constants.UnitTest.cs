﻿namespace GymDdd.SourceGenerator.Tests.Unit.Abstractions.Constants;

public static partial class Constants
{
    public static class UnitTest
    {
        public const string SourceGenerator = nameof(SourceGenerator);
    }
}
