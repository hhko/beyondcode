﻿namespace GymDdd.Framework.BaseTypes.Cqrs;

public interface IResponse;