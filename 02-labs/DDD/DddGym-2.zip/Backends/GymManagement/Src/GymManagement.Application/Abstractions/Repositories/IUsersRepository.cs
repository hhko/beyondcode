﻿//using GymManagement.Domain.AggregateRoots.Users;

//namespace GymManagement.Application.Abstractions.Repositories;

//public interface IUsersRepository
//{
//    Task AddUserAsync(User user);
//    Task<bool> ExistsByEmailAsync(string email);
//    Task<User?> GetByEmailAsync(string email);
//    Task<User?> GetByIdAsync(Guid userId);

//    Task UpdateAsync(User user);
//}