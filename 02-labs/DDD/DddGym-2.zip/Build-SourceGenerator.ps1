dotnet pack .\Abstractions\SourceGenerators\Src\GymDdd.SourceGenerator\GymDdd.SourceGenerator.csproj -c Release -o ./Abstractions
