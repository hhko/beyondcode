﻿namespace HostName.Application.Usecases.EntityNames.Queries.QueryName;

internal sealed class QueryNameQueryTelemetry
{
}
