﻿namespace HostName.Application.Usecases.EntityNames.Commands.CommandName;

internal sealed class CommandNameCommandTelemetry
{
}
