﻿namespace GymManagement.Tests.Unit.LayerTests.Domain.Constants;

public static partial class DomainConstants
{
    public static class User
    {
        public static readonly Guid Id = Guid.NewGuid();
    }
}