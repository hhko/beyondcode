﻿namespace GymDdd.Framework.WebApi.Utilities;

internal static class ProblemDetailsUtilities
{

}
