﻿namespace GymManagement.Tests.Unit.Abstractions.Constants;

public static partial class AssemblyConstants
{
    public static class IntegrationTest
    {
        public const string Appsettings_Integration_Json = "appsettings.Integration.json";

        //public const string DatabaseOptions = nameof(DatabaseOptions);
        //public const string BackgroundJobs = nameof(BackgroundJobs);
        public const string WebApi = nameof(WebApi);
    }
}