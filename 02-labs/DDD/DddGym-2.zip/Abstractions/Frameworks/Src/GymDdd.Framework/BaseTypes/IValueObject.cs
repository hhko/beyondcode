﻿namespace GymDdd.Framework.BaseTypes;

public interface IValueObject
{
    //const string SingleValueName = "Value";
    const string CreateMethodName = "Create";
    const string ValidateMethodName = "Validate";
}
